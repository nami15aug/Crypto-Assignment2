#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

float square_root(float x)
{
  return sqrt(x);
}

float calculate_pi(float probability)
{
  float temp;
  temp = 6.0f/probability;
  return square_root (temp);
}

uint32_t ecluidean_gcd(uint32_t x, uint32_t y)
{
  uint32_t temp;

  if (x < y)
  {
    temp = y;
    y = x;
    x = temp;
  }

  while (x % y != 0)
  {
    x += y;
    y = x - y;
    x = x - y;
    y %= x;
  }

  return y;
}

int main()
{
  uint32_t x;
  uint32_t y;
  uint32_t res;
  uint32_t i;
  uint32_t count = 0;
  float probability;
  float pi;

  uint32_t max_times = 1000;

  printf ("\nGCD calculation in progress");
  for(i = 0; i< max_times; i++)
  {
    x = rand();
    y = rand();
    res = ecluidean_gcd(x, y);
    if (res == 1)
      count ++;
  }

  probability = (float)count / (float)max_times;
  pi = calculate_pi(probability);


  printf ("\nThe number of times the GCD is equal to 1 is %u out of %u times", count, max_times);
  printf ("\nThe probability of GCD equal to 1 is %f", probability);
  printf ("\nThe value of PI is: %f", pi);
  printf("\nTo get the value of PI as 3.14, we need to try GCD on many samples - update max_times param and re-execute ");

  return 0;
}
